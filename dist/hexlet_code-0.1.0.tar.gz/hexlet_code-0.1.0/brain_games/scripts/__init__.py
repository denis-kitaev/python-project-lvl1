"""Brain Games scripts."""
